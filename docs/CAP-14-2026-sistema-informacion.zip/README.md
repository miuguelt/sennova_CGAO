# Paquete de referencia SENNOVA

Proyecto: **CAP-14-2026 Sistema de información para la gestión de proyectos de investigación del CGAO (referencia de validación)**  
Identificador: `2f8ac792-c560-524c-8962-95a8a3236e0b`  
Corte de datos: 2026-10-04

## Contenido

- `fuentes_originales/`: 5 archivos asociados en SENNOVA, copiados sin modificar. Los hashes SHA-256 se encuentran en `manifest.json`.
- `borradores_generados/`: 11 archivos Office, uno por cada formulario documental disponible para esta referencia.
- `manifest.json`: fuente, huellas, pendientes por campo y estado de generación.

## Estado del paquete

Los borradores se generaron con los datos actuales de SENNOVA, sin escribir en la base ni crear versiones. Contienen **399 pendientes de campo** distribuidos entre 11 documentos. El generador oficial de la aplicación sigue bloqueando el guardado de versiones hasta completar los campos obligatorios. Los pendientes se representan en los archivos como «Pendiente por diligenciar». No se crearon códigos SGPS, productos, fechas, montos ni evidencias.

Las fuentes conservan exactamente el formato original. Los borradores usan el renderer vigente de la aplicación; el informe final emplea la plantilla GCDTP-F-023 V01 empaquetada. Los demás borradores no son copias visuales exactas de cada archivo fuente. No están firmados, revisados ni listos para radicar.
